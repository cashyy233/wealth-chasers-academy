WEALTH CHASERS ACADEMY — INTERACTIVE EDITION

Included:
- Mobile-friendly black-and-gold website
- Four-week beginner NQ/MNQ course with completion tracking
- Embedded YouTube candlestick lessons
- Fictional-price trading game using virtual dollars
- Quiz arena with explanations
- NQ/MNQ risk calculator
- Practice journal with JSON export
- Flashcards
- Browser-local progress storage

To publish:
1. Open your existing wealth-chasers-academy GitHub repository.
2. Replace its index.html with this index.html.
3. Keep GitHub Pages set to branch main and folder /(root).
4. Wait a few minutes and reload your published site.

Limitations:
This is a static website. It does not have secure login, payment verification, synced student progress, instructor database, or live market data. Journal, game, and progress data are saved only in the same browser/device. The game uses fictional random prices and places no real trades. Educational content only, not financial advice.
